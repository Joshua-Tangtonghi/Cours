#include <stdio.h>
#include <stdlib.h>

int main() {
	int first = 2;
	int second = 3;

	printf("%d + %d = %d\n",
		    first, second, first + second);
	exit(EXIT_SUCCESS);
}