#include <stdio.h>
#include <stdlib.h>

int main() {
	unsigned int positif = 4294967295;
	printf("positif est un entier : %d\n", positif);
	printf("ne soyons pas négatif, positif est : %u\n", positif);
	exit(EXIT_SUCCESS);
}