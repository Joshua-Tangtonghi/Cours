#include <stdio.h>
#include <stdlib.h>

int main() {
  
  /* TODO : déclarer un entier ent1 */
  /* TODO : déclarer un nombre à virgule vir1 */
  /* TODO : définir un entier ent2 à valeur 42 */
  /* TODO : définir un entier chr1 à valeur '@' */
  /* TODO : faire prendre à vir1 la valeur 13.37 */
  /* TODO : faire prendre à ent1 la valeur de ent2 */
  
  exit(EXIT_SUCCESS);
}