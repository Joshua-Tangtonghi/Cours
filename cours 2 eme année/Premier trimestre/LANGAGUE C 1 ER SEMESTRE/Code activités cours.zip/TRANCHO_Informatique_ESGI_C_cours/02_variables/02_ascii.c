#include <stdio.h>
#include <stdlib.h>

int main() {
	char chiffre = '2';
	int lettre = 'x';
	printf("chiffre = %d : '%c'\n", chiffre, chiffre);
	printf("lettre = %d : '%c'\n", lettre, lettre);
	exit(EXIT_SUCCESS);
}