#include <stdio.h>
#include <stdlib.h>

int main() {
	printf("sizeof(char) :  %lu\n", sizeof(char));
	printf("sizeof(short) : %lu\n", sizeof(short));
	printf("sizeof(int) :   %lu\n", sizeof(int));
	printf("sizeof(long) :  %lu\n", sizeof(long));
	exit(EXIT_SUCCESS);
}