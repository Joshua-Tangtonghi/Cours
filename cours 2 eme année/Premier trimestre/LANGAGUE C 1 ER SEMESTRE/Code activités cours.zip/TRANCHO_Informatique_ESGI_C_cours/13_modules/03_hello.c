#include <stdio.h>

int main() {
  printf("Hello ESGI !\n");
  return 0;
}