/* main.c */

#include <stdlib.h>

extern void maFonction();

int main() {
  maFonction();
  exit(EXIT_SUCCESS);
}