/* mes_fonctions.c */

#include <stdio.h>

void maFonction() {
  printf("Ma Fonction\n");
}