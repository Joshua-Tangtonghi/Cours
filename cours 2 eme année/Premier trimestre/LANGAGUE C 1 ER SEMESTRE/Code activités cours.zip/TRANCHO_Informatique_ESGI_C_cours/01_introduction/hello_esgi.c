#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Hello ESGI !\n");
    exit(EXIT_SUCCESS);
}