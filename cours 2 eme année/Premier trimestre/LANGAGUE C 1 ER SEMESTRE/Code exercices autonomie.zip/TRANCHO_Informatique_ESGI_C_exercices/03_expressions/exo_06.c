#include <stdio.h>
#include <stdlib.h>

int main() {
    int a, b;
    /* TODO : demander des valeurs pour a et b */
    /* TODO : afficher l'addition de a et b */
    /* TODO : échanger les valeurs de a et de b */
    /* TODO : afficher la soustraction de a et b */
    long c;
    /* TODO : affecter à c le résultat de la multiplication de a et b */
    float d;
    /* TODO : affecter à d le résultat de la division fractionnaire de a et b */
    exit(EXIT_SUCCESS);
}