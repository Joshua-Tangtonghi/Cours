#include <stdio.h>
#include <stdlib.h>

int main() {
    /* À vous de jouer : */
	
	
	
	
	
	
	
	
    exit(EXIT_SUCCESS);
}