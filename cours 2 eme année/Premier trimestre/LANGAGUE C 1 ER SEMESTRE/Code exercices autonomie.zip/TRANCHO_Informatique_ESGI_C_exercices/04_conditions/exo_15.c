#include <stdio.h>
#include <stdlib.h>

int main() {
    int first_pass = 0, second_pass = 0;
    
    if(first_pass > second_pass) {
        /* Echanger first_pass et second_pass */
        
        
    }
    if(/* Condition : si mot de passe erroné */
    
    ) {
        printf("Accès refusé.\n");
        exit(EXIT_SUCCESS);
    }
    printf("Bienvenue !\n");
    exit(EXIT_SUCCESS);
}