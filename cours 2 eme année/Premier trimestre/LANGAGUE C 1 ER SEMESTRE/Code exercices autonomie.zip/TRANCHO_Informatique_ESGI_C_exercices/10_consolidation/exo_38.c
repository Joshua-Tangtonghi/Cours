#include <stdio.h>
#include <stdlib.h>

int main() {
  const char * infos = "Linus Torvalds 52 ans C";
  /* TODO : extraire les informations */
  exit(EXIT_SUCCESS);
}