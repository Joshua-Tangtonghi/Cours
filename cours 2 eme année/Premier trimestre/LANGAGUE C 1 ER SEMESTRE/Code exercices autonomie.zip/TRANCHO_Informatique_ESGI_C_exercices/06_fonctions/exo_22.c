#include <stdio.h>
#include <stdlib.h>

float moyenne();

int main() {
    printf("La moyenne de ");
    printf("= %g\n", moyenne());
    exit(EXIT_SUCCESS);
}