#include <stdio.h>
#include <stdlib.h>

int menu() {
    /* À vous de jouer */
}

int main() {
    printf("%d, bien reçu.\n", menu());
    exit(EXIT_SUCCESS);
}