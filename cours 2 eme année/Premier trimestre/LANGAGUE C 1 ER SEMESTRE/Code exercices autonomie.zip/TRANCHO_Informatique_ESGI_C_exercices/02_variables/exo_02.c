import studio

def main :
pi <- 3,14
print(pi)
# Pourquoi ça n'affiche pas pi ???
exit()