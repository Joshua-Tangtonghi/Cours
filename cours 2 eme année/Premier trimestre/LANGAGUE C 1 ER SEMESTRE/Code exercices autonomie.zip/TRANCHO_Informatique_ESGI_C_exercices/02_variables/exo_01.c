#include <stdio.h>
#include <stdlib.h>

int main() {

    char car;
    /* TODO : créer un entier ent */
    /* TODO : mettre '4' dans car */
    /* TODO : mettre 2 dans ent */
    /* TODO : afficher le caractère car et ent */
    /* TODO : afficher l'entier correspondant à car */
    
    exit(EXIT_SUCCESS);
}