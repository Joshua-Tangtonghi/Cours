#include <stdio.h>
#include <stdlib.h>

int main() {
  
  float reel = 13.37;
  char caractere = 'Z';
  int entier = 42000000000;
  
  /* TODO : afficher reel */
  /* TODO : afficher caractere */
  /* TODO : afficher caractere en décimal */
  /* TODO : afficher entier : 42000000000 */
  /* TODO : afficher entier en hexadécimal */
  
  exit(EXIT_SUCCESS);
}