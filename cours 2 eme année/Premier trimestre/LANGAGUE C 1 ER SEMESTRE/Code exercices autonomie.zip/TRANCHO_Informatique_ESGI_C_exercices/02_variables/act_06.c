#include <stdio.h>
#include <stdlib.h>

int main() {
  
  double reel;
  
  /* TODO : demander lecture de reel */
  /* TODO : lire reel */
  /* TODO : afficher reel */
  
  exit(EXIT_SUCCESS);
}